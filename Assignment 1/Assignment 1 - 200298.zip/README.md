Assignments for course CS253 - Software Development and Operations under Prof. Indranil Saha, IIT Kanpur

## Build (Linux)

### SQLite Library

```
sudo apt-get install libsqlite3-dev
```

### Compile and Execute (Linux)

```
g++ Assign1.cpp -o Assign1.exe -lsqlite3
./Assign1
```
